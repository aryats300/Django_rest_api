from django.apps import AppConfig


class UseridentityConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'UserIdentity'
    
